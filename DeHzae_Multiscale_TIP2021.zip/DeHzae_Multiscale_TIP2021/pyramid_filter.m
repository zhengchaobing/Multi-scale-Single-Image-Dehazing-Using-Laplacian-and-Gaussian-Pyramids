
function f = pyramid_filter;
%   f = [.0625, .25, .375, .25, .0625];
  f = [0, .25, .5, .25, 0];